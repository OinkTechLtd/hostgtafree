const HOSTS = ['https://hostgta.ru', 'https://hostgta.com'];

// ID для declarativeNetRequest правил (по одному на хост)
const COOKIE_RULE_ID = {
    'hostgta.ru': 9001,
    'hostgta.com': 9002
};

// При установке
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === "install") {
        chrome.tabs.create({ url: "https://hostgtafree.tatnet.app/welcome" });
    }
    // Создаем будильник для проверки каждые 6 часов
    chrome.alarms.create("checkServers", { periodInMinutes: 360 });
    checkAllServers();
});

// При удалении (через setUninstallURL)
chrome.runtime.setUninstallURL("https://hostgtafree.tatnet.app/feedback");

// Слушатель будильника
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "checkServers") {
        checkAllServers();
    }
});

// Многие мобильные Chromium-браузеры (Kiwi, Yandex и т.п.) не всегда
// прокидывают куки сайта в fetch() из service worker'а расширения, даже
// если в самой вкладке браузера сессия активна и пользователь залогинен.
// Чтобы это обойти, явно читаем куки через chrome.cookies и принудительно
// подставляем их в заголовок запроса через declarativeNetRequest —
// это работает независимо от того, почему конкретный браузер "теряет" куки.
async function forceCookieHeader(host) {
    const hostname = new URL(host).hostname;
    const ruleId = COOKIE_RULE_ID[hostname];
    if (!ruleId || !chrome.declarativeNetRequest) return false;

    try {
        const cookies = await chrome.cookies.getAll({ domain: hostname });
        if (!cookies || cookies.length === 0) {
            await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [ruleId] });
            return false;
        }

        const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

        await chrome.declarativeNetRequest.updateSessionRules({
            removeRuleIds: [ruleId],
            addRules: [{
                id: ruleId,
                priority: 1,
                action: {
                    type: 'modifyHeaders',
                    requestHeaders: [{ header: 'Cookie', operation: 'set', value: cookieHeader }]
                },
                condition: {
                    urlFilter: `||${hostname}/`,
                    resourceTypes: ['xmlhttprequest', 'other']
                }
            }]
        });
        return true;
    } catch (e) {
        console.error(`[HostGta Free] forceCookieHeader(${hostname}) failed:`, e);
        return false;
    }
}

async function checkAllServers() {
    for (const host of HOSTS) {
        try {
            // Принудительно прокидываем актуальные куки браузера в запрос
            await forceCookieHeader(host);

            const response = await fetch(`${host}/web`, {
                method: 'GET',
                credentials: 'include',
                redirect: 'follow',
                headers: {
                    'Cache-Control': 'no-cache'
                }
            });

            const text = await response.text();
            const finalUrl = response.url || '';
            // Если нас перекинуло на страницу логина — точно не авторизован
            const redirectedToLogin = finalUrl.includes('/login') || finalUrl.includes('/auth');

            const servers = parseServers(text);

            // Несколько независимых признаков авторизации. Самый надежный —
            // успешно распарсенные карточки серверов: если они нашлись,
            // значит мы 100% видим личный кабинет, а не страницу входа.
            const hasAuthMarkers = text.includes('exitgood') ||
                                    text.includes('user_info') ||
                                    text.includes('/logout') ||
                                    text.includes('/web/time/');

            const isAuth = !redirectedToLogin && (servers.length > 0 || hasAuthMarkers);

            console.log(`[HostGta Free] ${host}: auth=${isAuth}, servers=${servers.length}, redirected=${redirectedToLogin}, finalUrl=${finalUrl}`);

            if (!isAuth) {
                chrome.storage.local.set({ [`auth_${host}`]: false, [`servers_${host}`]: [] });
                continue;
            }

            chrome.storage.local.set({ [`auth_${host}`]: true });

            console.log(`Found ${servers.length} servers on ${host}`);

            for (const server of servers) {
                // Если осталось 3 дня или меньше (и больше 0)
                if (server.daysLeft <= 3 && server.daysLeft > 0) {
                    await renewServer(host, server.id);
                    showNotification(server.id, server.daysLeft);
                }
            }

            chrome.storage.local.set({ [`servers_${host}`]: servers, lastCheck: Date.now() });
        } catch (e) {
            console.error(`Error checking ${host}:`, e);
        }
    }
}

function parseServers(html) {
    const servers = [];
    // Улучшенный парсинг: ищем блоки с ID и днями более глобально
    const serverBlocks = html.split('table-content__row').slice(1);

    serverBlocks.forEach(block => {
        const idMatch = block.match(/\/web\/base\/(\d+)/);
        const daysMatch = block.match(/(\d+)\s+(дней|дня|день)/);

        if (idMatch) {
            servers.push({
                id: idMatch[1],
                daysLeft: daysMatch ? parseInt(daysMatch[1]) : 0,
                status: block.includes('Активен') ? 'active' : 'inactive'
            });
        }
    });
    return servers;
}

async function renewServer(host, serverId) {
    try {
        // Важно: передаем credentials + принудительно подставленные куки
        await forceCookieHeader(host);
        await fetch(`${host}/web/time/${serverId}`, {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'time=30'
        });
    } catch (e) {
        console.error("Renew failed", e);
    }
}

// Слушатель сообщений от Popup для мгновенной проверки
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "checkNow") {
        checkAllServers().then(() => sendResponse({success: true}));
        return true;
    }
});

function showNotification(serverId, days) {
    chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'HostGta Free: Сервер продлен!',
        message: `Ваш веб-сервер #${serverId} автоматически продлен на 30 дней (оставалось: ${days} дн.)`,
        priority: 2
    });
}
